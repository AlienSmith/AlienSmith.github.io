return
{
--VertexCount =4
VertexData = {{-5,0,5},
{5,0,5},
{-5,0,-5},
{5,0,-5},
},
--IndexCount =6
IndexData  = {0,1,2,2,1,3,},
}
