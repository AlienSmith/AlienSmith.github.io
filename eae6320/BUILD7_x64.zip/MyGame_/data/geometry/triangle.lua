return{
	-- Triangle
	-- VertexCount = 3
	VertexData = {{0.0,0.0,0.0},
				  {1.0,0.0,0.0},
				  {1.0,1.0,0.0}},
	-- IndexCount = 3
	IndexData  = {0,1,2},
}