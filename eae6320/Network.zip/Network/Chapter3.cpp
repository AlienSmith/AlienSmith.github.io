#include"Chapter3.h"
unsigned int Networking::OO::SyncTCPServer::BACK_BUF_SIZE = 30;
std::string Networking::OO::SyncTCPServer::EMULATE_LONG_COMP_OP = "EMULATE_LONG_COMP_OP";